package com.example.myapplication.Interface;

//import com.agrotech.karyfresh.Model.ProductResponseModel_spinner;

import com.example.myapplication.Model.UserRequest;
import com.example.myapplication.Model.UserResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface WebServiceInterface {


    String weburl = "http://192.168.1.83:5050/";


//======================================================

    //Login Page
//    @FormUrlEncoded
//    @POST("register")
//    Call<ResponseBody> saveUser(@Field("username")String username,
//                                @Field("password")String password,
//                                @Field("email")String email,
//                                @Field("mobile")String mobile
//    );

//    @FormUrlEncoded
//    @POST("postinfo")
//    Call<ResponseBody>saveuser(
//            @FieldMap Map<String, String > map
//            );


    @POST("register")
    Call<UserResponse>saveuser(@Body UserRequest userRequest);



    @GET("data")
    Call<String> getSlotData(
            @Query("email") String email,
            @Query("password") String password
    );
}


